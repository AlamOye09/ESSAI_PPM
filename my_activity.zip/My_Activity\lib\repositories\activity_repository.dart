import '../data/activity_data.dart';
import '../models/activity_model.dart';

class ActivityRepository {
  final ActivityData _data = ActivityData();

  // Mengambil seluruh data aktivitas
  List<ActivityModel> getAllActivities() {
    return _data.activities;
  }

  // Mengambil satu aktivitas berdasarkan ID
  ActivityModel? getActivityById(String id) {
    try {
      return _data.activities.firstWhere((item) => item.id == id);
    } catch (e) {
      return null;
    }
  }

  // Menambahkan aktivitas baru
  void addActivity(ActivityModel activity) {
    _data.activities.add(activity);
  }

  // Mengubah nama aktivitas
  void updateActivityName(String id, String newName) {
    final activity = getActivityById(id);
    if (activity != null) {
      activity.name = newName;
    }
  }

  // Menghapus aktivitas
  void deleteActivity(String id) {
    _data.activities.removeWhere((item) => item.id == id);
  }

  // Memperbarui nilai counter
  void updateCounter(String id, int newCounter) {
    final activity = getActivityById(id);
    if (activity != null) {
      activity.counter = newCounter;
    }
  }
}