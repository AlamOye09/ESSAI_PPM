import '../models/activity_model.dart';

class ActivityData {
  // Penyimpanan sementara menggunakan List dengan data awal
  final List<ActivityModel> _activities = [
    ActivityModel(id: '1', name: 'Membaca Buku (Halaman)', counter: 15),
    ActivityModel(id: '2', name: 'Olahraga Push-Up', counter: 20),
    ActivityModel(id: '3', name: 'Minum Air Putih (Gelas)', counter: 5),
  ];

  List<ActivityModel> get activities => _activities;
}